//=========================================================================
// kfxEVRS_License.h
//
// Copyright (c) 2020 Kofax. All rights reserved. Kofax Confidential.
// Unauthorized use, duplication, distribution, or disclosure is strictly
// prohibited.
//
// Kofax Mobile SDK
//    License Generated:  November 2, 2020
//    Expiration Date:    February 2, 2021
//
//=========================================================================

#ifndef kfxEVRS_License_h
#define kfxEVRS_License_h

#define PROCESS_PAGE_SDK_LICENSE "jV[0tUzfdlzjcN,#^9(G4VNm^(U%80[KTA`j^vrPfl4j6cIkDfd5FqB,n!Z8lF0gd!k5,&N!!tL@Iv=!BDUEOb!hhWjZ;,5h[7?#"

#endif
