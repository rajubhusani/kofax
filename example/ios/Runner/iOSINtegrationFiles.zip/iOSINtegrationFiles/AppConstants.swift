//
//  CaptureConroller.swift
//  CheckCaptureFAB
//
//  Created by Vimlesh Bhatt on 12/1/2021.
//  Copyright © 2020 Kofax. All rights reserved.
//

import UIKit

class AppConstants {
    
    static let ScanTypeFront = "front"
    static let ScanTypeBack = "back"
    static let ScanTypeBoth = "both"
    
    // JSON Parameter
    static let jsonParamFront = "front"
    static let jsonParamBack = "back"
    static let jsonParamMicr = "micr"
    
    // ScanOperation
    enum ChequeScanOperation:Int {
        case COMPLETED = 0
        case CANCELLED = 1
    }
    
    static let capturedImageFrameMaxWidth:CGFloat = 400.0
    static let capturedImageFrameMaxHeight:CGFloat = 600.0
    
    // Kofax lincence Key
    static let kofaxLicenceKey = "jV[0tUzfdlzjcN,#^9(G4VNm^(U%80[KTA`j^vrPfl4j6cIkDfd5FqB,n!Z8lF0gd!k5,&N!!tL@Iv=!BDUEOb!hhWjZ;,5h[7?#"

    static let singleSideCaptureCount = 1
    static let bothSideCaptureCount = 2
    
    //
    static let imageProcessingString = "_DeviceType_2_DoSkewCorrectionPage__DoCropCorrection__DoScaleImageToDPI_300_DoRecognizeTextMICR__DocDimLarge_8.27"
    
}

