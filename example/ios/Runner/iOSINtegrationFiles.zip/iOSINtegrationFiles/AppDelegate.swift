import UIKit
import Flutter
import GoogleMaps
import Firebase

@UIApplicationMain
@objc class AppDelegate: FlutterAppDelegate {
    
    var imgView:UIImageView?
    var channel:FlutterMethodChannel?
    var flutterController:FlutterViewController?
    var _result:FlutterResult? = nil
    
    override func application(
        _ application: UIApplication,
        didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?
    ) -> Bool {
        GMSServices.provideAPIKey("AIzaSyCPmgjngrSplRappbHYrnPtcQJIscaY-Fs")
        FirebaseApp.configure()
        
        GeneratedPluginRegistrant.register(with: self)
        
        self.flutterController = self.window.rootViewController as? FlutterViewController;
        
        self.channel = FlutterMethodChannel.init(name: "kofax", binaryMessenger: flutterController as! FlutterBinaryMessenger)
        
        self.channel?.setMethodCallHandler { (call: FlutterMethodCall, result: @escaping FlutterResult) in
            
            // Capture the result in global variable
            self._result = result
            
            switch call.method {
            case "chequeScan":
                
                if let args = call.arguments as? Dictionary<String, Any>,
                   let scanType = args["scanType"] as? String {
                    
                    let storyboard : UIStoryboard? = UIStoryboard.init(name:"Main", bundle: .main);
                    let captureVC = storyboard!.instantiateViewController(withIdentifier: "CaptureController") as? CaptureController
                    captureVC?.scanType = scanType
                    captureVC?.modalPresentationStyle = .fullScreen
                    
                    captureVC?.onDismisPresentVC = { (operation:AppConstants.ChequeScanOperation) in
                        self.flutterController?.dismiss(animated: true, completion: {
                            switch operation{
                            case .COMPLETED:
                                self._result!(CaptureManager.sharedInstance.imageString())
                                break;
                            case .CANCELLED:
                                self._result?(FlutterError.init(code: "CANCELLED", message: lfk.CANCELLED_ERROR.localized, details: nil))
                                break;
                            }
                        })
                    }
                    
                    self.flutterController?.present(captureVC!, animated: true, completion: nil)
                    
                }else {
                    // Handle invalid argumets here
                    self._result?(FlutterError.init(code: "CANCELLED", message: lfk.CANCELLED_ERROR.localized, details: nil))
                }
                break;
                
            case "mockScan":
                self._result!(CaptureManager.sharedInstance.imageString())
                break
                
            default:
                result(FlutterMethodNotImplemented);
            }
        }
        
        
        return super.application(application, didFinishLaunchingWithOptions: launchOptions)
    }
    
    override func applicationWillResignActive(_ application: UIApplication) {
        imgView = UIImageView.init(frame: self.window.frame)
        imgView?.image = UIImage.init(named: "bg");
        if imgView != nil{
            self.window.addSubview(imgView!);
        }
    }
    
    override func applicationDidBecomeActive(_ application: UIApplication) {
        if imgView != nil{
            imgView?.removeFromSuperview();
            imgView = nil;
        }
    }
}
