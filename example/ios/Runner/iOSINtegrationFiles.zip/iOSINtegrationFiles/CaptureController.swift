//
//  CaptureConroller.swift
//  CheckCaptureFAB
//
//  Created by Vimlesh Bhatt on 26/12/2020.
//  Copyright © 2020 Kofax. All rights reserved.
//

import Foundation
import UIKit

let lfk = LocalizedFileKeys.self
class CaptureController:UIViewController, kfxKUIImageCaptureControlDelegate, kfxKIPDelegate {
    
    enum Format: String {
        case png = "png"
        case jpeg = "jpeg"
    }
    
    enum PROCESSSTATUS:Int {
        case PS_START = 0
        case PS_QUICK_ANALYSIS = 1
        case PS_IMAGE_PROCESSING = 2
        case PS_IMAGE_PROCESSING_FINISHED = 3
        case PS_DATA_EXTRACTION = 4
        case PS_FINISHED = 5
    }
    
    enum CURRENT_SCAN_SIDE:Int {
        case NONE = 0
        case FRONT = 1
        case BACK = 2
    }
    
    var onDismisPresentVC : ((_ operation:AppConstants.ChequeScanOperation) -> Void)?
    
    // Capture Configurations
    var numberOfPagesToCapture = 2
    
    var processStatus:PROCESSSTATUS?
    var currentScanSide:CURRENT_SCAN_SIDE = .NONE
    var imageProcessor:kfxKENImageProcessor?
    var theCurrentImage:kfxKEDImage = kfxKEDImage.init()
    
    // The Image Review and Edit Control
    var imageView:kfxKUIImageReviewAndEdit?
    var imageCaptureControl:kfxKUIImageCaptureControl?
    var checkCaptureExperience:kfxKUICheckCaptureExperience?;
    // CaptureConfigurations
    
    // Auto Torch
    var autoTorch = false;
    var SHOW_TUTORIAL_SAMPLE_IMAGE = true
    var allowManualCapture = false
    var doQuickAnalysis = true
    var shouldWaitForUserInput = true
    let cropToTargetFrame = false
    
    // ScanType
    var scanType:String?
    
    // The found MICR line
    var micrLine:String?
    var micrTop:Int?, micrLeft:Int?, micrWidth:Int?, micrHeight:Int?
    
    // MARK: - Button Actions
    var rotateLabel:UILabel = UILabel.init(frame: .zero)
    @IBOutlet weak var instructionLabel: UILabel!
    
    @IBOutlet weak var btnUse: UIButton!
    @IBAction func sel_btnUse(_sender : UIButton){
        
        self.showOkRetryButtons(show: false)
        
        switch self.processStatus {
        case .PS_QUICK_ANALYSIS:
            doImageProcessing(img: self.theCurrentImage)
            break
        case .PS_IMAGE_PROCESSING_FINISHED:
            // If capture images count is less than the number of images required for the capture process, ask to capture further images.
            if (CaptureManager.sharedInstance.capturedImages.count < self.numberOfPagesToCapture) {
                self.updateCaptureSide()
                self.freeImageViewControl()
                self.startCaptureProcess()
            } else {
                // End capture process when all the images are captured.
                self.onDismisPresentVC!(.COMPLETED)
            }
            break
        default:
            break
        }
    }
    
    private func updateCaptureSide(){
        
        if (self.scanType == AppConstants.ScanTypeBoth) {
            self.currentScanSide =  self.currentScanSide == .FRONT ? .BACK : self.currentScanSide == .BACK ? .NONE : .NONE
        }else if (self.scanType == AppConstants.ScanTypeFront) {
            self.currentScanSide =  self.currentScanSide == .FRONT ? .FRONT : .NONE
        }else if (self.scanType == AppConstants.ScanTypeBack) {
            self.currentScanSide =  self.currentScanSide == .BACK ? .BACK : .NONE
        }
    }
    
    @IBOutlet weak var btnRescan: UIButton!
    @IBAction func sel_btnRescan(_sender : UIButton){
        
        self.showOkRetryButtons(show: false)
        self.freeImageViewControl()
        
        if (self.processStatus == .PS_IMAGE_PROCESSING_FINISHED) {
            CaptureManager.sharedInstance.clear()
        }
        
        // Start again the Camera
        self.startCaptureProcess()
    }
    
    @IBOutlet weak var btnManualCapture: UIButton!
    @IBAction func sel_btnManualCapture(_sender : UIButton){
        
        self.checkCaptureExperience?.stopCapture()
        self.imageCaptureControl?.forceTakePicture()
    }
    
    @IBAction func btnBack(_sender : UIButton){
        self.onDismisPresentVC!(.CANCELLED)
    }
    
    // MARK: - View Lifecycle methods
    override func viewDidLoad() {
        super.viewDidLoad()
        setLicennceAndInitializeSDK()
        
        // Initally we will start capturing the fonrt side.
        self.currentScanSide = (self.scanType == AppConstants.ScanTypeFront || self.scanType == AppConstants.ScanTypeBoth) ? .FRONT : .BACK
        
        // Configure numberOfPages to capture based on scanType
        self.numberOfPagesToCapture = self.scanType == AppConstants.ScanTypeBoth ? AppConstants.bothSideCaptureCount : AppConstants.singleSideCaptureCount
    }
    
    func setLicennceAndInitializeSDK(){
        // Check Kofax SDK licensing. Enter the KMC SDK License string in "KofaxFrameworks - kfxEVRS_license.h" or enter it directly here
        let license:kfxKUTLicensing = kfxKUTLicensing()
        
        let resp = license.setMobileSDKLicense(AppConstants.kofaxLicenceKey);
        
        if (resp != KMC_SUCCESS) {
            print("Kofax SDK licencen eror")
        } else {
            // Initialize kfxKUIImageCaptureControl class
            kfxKUIImageCaptureControl.initializeControl()
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        
        super.viewWillAppear(animated)
        
        // Clear data once only the user comes in for Both Scan.
        if(self.scanType == AppConstants.ScanTypeBoth){ CaptureManager.sharedInstance.clear()}
    
        // addCaptureINstructionlabelToCaptureView
        addCaptureInstructionlabelToCaptureView()
        
        // Enable/Disable Console Logging of KMC libraries
        kfxLogging.enableConsoleLogging(false)
        kfxKUILogging.enableConsoleLogging(false)
        kfxKENLogging.enableConsoleLogging(false)
        kfxKUTLogging.enableConsoleLogging(false)
        
        self.showOkRetryButtons(show: false)
        self.startCaptureProcess()
    }
    
    func addCaptureInstructionlabelToCaptureView() {
        
        rotateLabel.layer.anchorPoint = CGPoint(x: 0, y: 1)
        instructionLabel.transform = CGAffineTransform.init(rotationAngle: .pi/2)
        instructionLabel.frame = CGRect(x: self.view.bounds.size.width/2, y:self.view.bounds.size.width/2, width: self.view.bounds.size.width, height: 40)
        
        rotateLabel = UILabel(frame: CGRect(x: self.view.bounds.size.width/2, y:self.view.bounds.size.width/2, width: self.view.bounds.size.width, height: 40))
        rotateLabel.layer.anchorPoint = CGPoint(x: 0, y: 1)
        rotateLabel.textAlignment = .right
        rotateLabel.textColor = .white
        rotateLabel.isHidden = false
        rotateLabel.numberOfLines = 0
        rotateLabel.lineBreakMode = .byWordWrapping
        
        if ((self.currentScanSide == .FRONT) && (self.scanType == AppConstants.ScanTypeFront || self.scanType == AppConstants.ScanTypeBoth)) {
            rotateLabel.text = lfk.CAMERA_VIEW_FRONT_HINT_TEXT.localized
        } else if ((self.currentScanSide == .BACK) && (self.scanType == AppConstants.ScanTypeBack || self.scanType == AppConstants.ScanTypeBoth)) {
            rotateLabel.text = lfk.CAMERA_VIEW_BACK_HINT_TEXT.localized
        }else {
            rotateLabel.text = ""
        }

        self.view.addSubview(rotateLabel)
        rotateLabel.transform = CGAffineTransform.init(rotationAngle: .pi/2)
    }
    
    // MARK: - Capture Process
    
    func startCaptureProcess() {
        rotateLabel.isHidden = false
        hideStatusIndicator()
        
        self.processStatus = .PS_START
        self.showOkRetryButtons(show: false)
        self.showManualCaptureButton(show: true)
        
        initializeCaptureControlWithCaptureExperience()
        
    }
    
    func initializeCaptureControlWithCaptureExperience() {
        
        // Initialize the Camera Control and the Document Capture Experience
        
        if (imageCaptureControl != nil) {
            // Do nothing, already initialized
            return;
        }
        
        // Init Image Capture Control with a specific size
        imageCaptureControl = kfxKUIImageCaptureControl.init(frame: CGRect(x: 0, y: 0, width: self.view.bounds.size.width, height: self.view.bounds.size.height))
        
        imageCaptureControl?.delegate = self
        
        // Front or Back Camera
        imageCaptureControl?.setCameraType(kfxKUIBackCamera)
        
        // Set the Flash/Torch
        if (autoTorch == true)
        {
            imageCaptureControl?.flash = kfxKUITorchAuto; // Auto Torch
        } else {
            imageCaptureControl?.flash = kfxKUIFlashOff; // Flash Off or On, or Auto
        }
        
        // Capture Mode (Camera or Video)
        imageCaptureControl?.useVideoFrame = false; // true = Video Capture, FALSE = Image Capture
        imageCaptureControl?.highResolutionStillImageEnabled = false;
        
        // The Document Capture Criteria Holder
        let checkCaptureExperienceCriteraHolder:kfxKUICheckCaptureExperienceCriteriaHolder  = kfxKUICheckCaptureExperienceCriteriaHolder.init()
        
        // Max Pitch and Roll
        checkCaptureExperienceCriteraHolder.pitchThreshold = 15;  // Max pitch in degrees (0 - 45; 45 .. disabled)
        checkCaptureExperienceCriteraHolder.pitchThresholdEnabled = true;
        checkCaptureExperienceCriteraHolder.rollThreshold = 15;  // Max roll in degrees (0 - 45; 45 .. disabled)
        checkCaptureExperienceCriteraHolder.rollThresholdEnabled = true;
        // Stability
        checkCaptureExperienceCriteraHolder.stabilityThreshold = 75;  // Min stability of the device (0 - 100)
        checkCaptureExperienceCriteraHolder.stabilityThresholdEnabled = true;
        // Focus Constraint
        checkCaptureExperienceCriteraHolder.focusConstraintEnabled = true;
        // Force proper page orientation
        checkCaptureExperienceCriteraHolder.pageOrientationEnabled = true;
        
        // The Document Detection Settings
        let checkDetectionSettings:kfxKEDCheckDetectionSettings = kfxKEDCheckDetectionSettings.init()
        
        // Frame - Document expected format
        //checkDetectionSettings.targetFrameAspectRatio = 29.7/21.0;   // 0 = disabed; long side / short side ( > 1) for landscape mode or short side / long side (< 1) for Portrait mode; e.g. 29.7cm / 21.0cm for A4
        
        checkDetectionSettings.targetFramePaddingPercent = 5; // The minimum padding in percent between the Frame and the Camera View borders (1 - 50);
        
        if ((self.currentScanSide == .FRONT) && (self.scanType == AppConstants.ScanTypeFront || self.scanType == AppConstants.ScanTypeBoth))
        {
            checkDetectionSettings.checkSide = KED_CHECK_SIDE_FRONT;
            rotateLabel.text = lfk.CAMERA_VIEW_FRONT_HINT_TEXT.localized
        } else if ((self.currentScanSide == .BACK) && (self.scanType == AppConstants.ScanTypeBack || self.scanType == AppConstants.ScanTypeBoth)){
            checkDetectionSettings.checkSide = KED_CHECK_SIDE_BACK;
            rotateLabel.text = lfk.CAMERA_VIEW_BACK_HINT_TEXT.localized
        }else{
            checkDetectionSettings.checkSide = KED_CHECK_SIDE_NONE;
            rotateLabel.text = ""
        }
        
        // assign Document Detection Settings to the Document Capture Experience
        checkCaptureExperienceCriteraHolder.checkDetectionSettings = checkDetectionSettings;
        
        // Force refocus before capturing
        checkCaptureExperienceCriteraHolder.refocusBeforeCaptureEnabled = true;
        
        // Create an instance of kfxKUIDocumentCaptureExperience with the critera
        self.checkCaptureExperience = kfxKUICheckCaptureExperience.init(captureControl: imageCaptureControl, criteria: checkCaptureExperienceCriteraHolder)
        
        if (SHOW_TUTORIAL_SAMPLE_IMAGE == true)
        {
            // Assign own tutorial image or use the default image
            //self.documentCaptureExperience.tutorialSampleImage = [UIImage imageNamed:@"test"];
            
            self.checkCaptureExperience?.tutorialEnabled = true;
            
            // Add Tap Gesture to Image Capture Control
            let tapGesture:UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.tapOnCaptureControl(_ :)))
            tapGesture.numberOfTapsRequired = 1;
            imageCaptureControl?.addGestureRecognizer(tapGesture)
        }
        
        // Frame Color
        self.checkCaptureExperience?.guidanceFrameColor = .white; // [UIColor colorWithRed:1.0 green:1.0 blue:1.0 alpha:0.8]; // The Frame Color (the four corners)
        self.checkCaptureExperience?.steadyGuidanceFrameColor = .green; // The Hold Steady Frame Color (the rectangle)
        
        // Do Vibrate after Image Capture
        self.checkCaptureExperience?.vibrationEnabled = true;
        
        // Configuration of the info texts
        if ((self.currentScanSide == .FRONT && CaptureManager.sharedInstance.capturedImages.count == 0) && (self.scanType == AppConstants.ScanTypeFront || self.scanType == AppConstants.ScanTypeBoth) ){
            self.checkCaptureExperience?.userInstruction.message = lfk.MSG_USERINSTRUCTION_FRONT.localized;
        } else
        {
            self.checkCaptureExperience?.userInstruction.message = lfk.MSG_USERINSTRUCTION_BACK.localized;
        }
        
        self.checkCaptureExperience?.userInstruction.orientation = kfxKUIMessageOrientationLandscapeLeft;
        self.checkCaptureExperience?.userInstruction.textColor = .white;
        self.checkCaptureExperience?.userInstruction.font = UIFont(name: "HelveticaNeue-Bold", size: 20)
        
        self.checkCaptureExperience?.zoomInMessage.message = lfk.MSG_ZOOM_IN.localized;
        self.checkCaptureExperience?.zoomInMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        self.checkCaptureExperience?.zoomOutMessage.message = lfk.MSG_ZOOM_OUT.localized;
        self.checkCaptureExperience?.zoomOutMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        self.checkCaptureExperience?.centerMessage.message = lfk.MSG_CENTER.localized;
        self.checkCaptureExperience?.centerMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        
        self.checkCaptureExperience?.capturedMessage.message = lfk.MSG_CAPTUREDONE.localized;
        self.checkCaptureExperience?.capturedMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        self.checkCaptureExperience?.holdSteadyMessage.message = lfk.MSG_HOLDSTEADY.localized;
        self.checkCaptureExperience?.holdSteadyMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        self.checkCaptureExperience?.rotateMessage.message = lfk.MSG_ROTATE.localized;
        self.checkCaptureExperience?.rotateMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        self.checkCaptureExperience?.holdParallelMessage.message = lfk.MSG_HOLDPARALLEL.localized;
        self.checkCaptureExperience?.holdParallelMessage.orientation = kfxKUIMessageOrientationLandscapeLeft;
        
        // Add imageCaptureControl into ViewController's view
        self.view.addSubview(imageCaptureControl!)
        
        // Move image capture view to back
        self.view.sendSubviewToBack(imageCaptureControl!)
        
        // Automatically take picture (constraints must be fulfilled)
        self.checkCaptureExperience?.takePicture()
    }
    
    func freeCaptureControl() {
        
        self.imageCaptureControl?.removeFromSuperview()
        self.imageCaptureControl = nil
        self.checkCaptureExperience = nil
    }
    
    // function which is triggered when handleTap is called
    @objc func tapOnCaptureControl(_ tapGesture: UITapGestureRecognizer) {
        checkCaptureExperience?.tutorialEnabled = false;
    }
    
    // MARK: - kfxKUIImageCaptureControlDelegate
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, stabilityDelay: Int32) {
        //print("imageCaptureControl :: Stability : %d", stabilityDelay);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, imageCapturedEvent: kfxKEDImageCapturedEvent!) {
        //print("imageCaptureControl :: %@, imageCapturedEvent : %d", imageCaptureControl!, imageCapturedEvent!);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, focusStateChanged isFocused: Bool) {
        //print("imageCaptureControl :: %@, focusStateChanged : %d", imageCaptureControl!, isFocused);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, pageDetected event: kfxKUIPageDetectionEvent!) {
        //print("imageCaptureControl :: %@, pageDetected : %d", imageCaptureControl!, event!);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, videoSampleAvailable videoSample: CMSampleBuffer!) {
        //print("imageCaptureControl :: %@, videoSample : %d", imageCaptureControl!, videoSample!);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, pitchChangedTo pitch: Int32, rollChangedTo roll: Int32) {
        //print("imageCaptureControl :: %@, focusStateChanged : %d roll :: %d ", imageCaptureControl!, pitch, roll);
    }
    
    func imageIsAboutToCapture(for imageCaptureControl: kfxKUIImageCaptureControl!) {
        //print("imageCaptureControl :: %@, focusStateChanged : %d", imageCaptureControl!);
    }
    
    func imageCaptureControl(_ imageCaptureControl: kfxKUIImageCaptureControl!, imageJustCaptured image: kfxKEDImage!) {
        
        self.freeCaptureControl()
        
        self.showImage(img: image)
        
        self.theCurrentImage = image
        self.theCurrentImage.imageMimeType = MIMETYPE_TIF
        
        // Go for quick analysis of the image
        if (self.doQuickAnalysis == true) {
            self.doQuickAnalysis(img: self.theCurrentImage)
        }
    }
    
    // Display Captured Image
    func showImage(img: kfxKEDImage) {
        rotateLabel.isHidden = true
        // Initialize kfxKUIImageReviewAndEdit
        kfxKUIImageReviewAndEdit.initializeControl()
        
        if (self.imageView == nil) {
            
            let frameWidth = self.view.bounds.size.width < AppConstants.capturedImageFrameMaxWidth ? self.view.bounds.size.width : AppConstants.capturedImageFrameMaxWidth
            
            let frameHeight = self.view.bounds.size.height < AppConstants.capturedImageFrameMaxHeight ? self.view.bounds.size.height : AppConstants.capturedImageFrameMaxHeight
            
            self.imageView = kfxKUIImageReviewAndEdit.init(frame:CGRect(x: 0, y: 0, width: frameWidth, height: frameHeight))
            self.view.addSubview(self.imageView!);
            self.imageView?.center = self.view.center
        }
        
        // Pass image into kfxKUIImageReviewAndEdit controller
        self.imageView!.setImage(img);
        
        // Move image view to back
        self.view.sendSubviewToBack(self.imageView!)
    }
    
    func showOkRetryButtons(show:Bool) {
        
        if (show == true)
        {
            self.btnUse.isEnabled = true;
            self.btnUse.isHidden = false;
            self.btnRescan.isEnabled = true;
            self.btnRescan.isHidden = false;
        } else {
           
            self.btnUse.isEnabled = false;
            self.btnUse.isHidden=true;
            self.btnRescan.isEnabled = false;
            self.btnRescan.isHidden = true;
        }
    }
    
    func showManualCaptureButton(show:Bool) {
        // Enable/Disable the Camera Button
        if ((show) && (self.allowManualCapture == true)) {
            self.btnManualCapture.isEnabled = true;
            self.btnManualCapture.isHidden = false;
        } else {
            self.btnManualCapture.isEnabled = false;
            self.btnManualCapture.isHidden = true;
        }
        
        self.btnManualCapture.bringSubviewToFront(self.view)
    }
    
    func freeImageViewControl() {
        // Remove the Image View Control
        self.imageView?.removeFromSuperview()
        self.imageView = nil;
    }
    
    func showStatusIndicator(statusMessage:String) {
        // Show progress indicators here
        DispatchQueue.main.asyncAfter(deadline: .now()) {
            if (statusMessage.count > 0)
            {
                SVProgressHUD.show(withStatus: statusMessage)
            } else {
                SVProgressHUD.show()
            }
            
        }
    }
    
    func hideStatusIndicator(){
        SVProgressHUD.dismiss()
    }
    
    func doImageProcessing(img:kfxKEDImage) {
        
        self.showStatusIndicator(statusMessage:lfk.STATUS_IMAGE_PROCESSING.localized)
        
        // Init Image Processor
        if (self.imageProcessor == nil) {
            self.imageProcessor = kfxKENImageProcessor.instance()
            self.imageProcessor?.delegate = self;
        }
        
        // The Image Processor Operation String
        var strOperations = "";
        strOperations = AppConstants.imageProcessingString;
        
        // Create the Image Processor Configuration with the Image Processing STring
        let ipConfiguration = KFXImageProcessorConfiguration.init(ippString:strOperations)
        
        // Crop captured image to to Target Frame before calling EVRS
        
        if (self.cropToTargetFrame)
        {
            ipConfiguration?.targetFrameCropType = TARGET_FRAME_CROP_ON;
        } else {
            ipConfiguration?.targetFrameCropType = TARGET_FRAME_CROP_OFF;
        }
        
        self.processStatus = .PS_IMAGE_PROCESSING;
        
        // Process image
        let resp = self.imageProcessor?.processImage(img, with: ipConfiguration)
        if (resp != KMC_SUCCESS)
        {
            self.showErrorReason(errorCode: resp ?? 0)
        }
    }
    
    // MARK: - Quick Analysis
    
    func doQuickAnalysis(img: kfxKEDImage) {
        
        self.showStatusIndicator(statusMessage: lfk.STATUS_QUICK_ANALYSIS.localized)
        
        self.processStatus = .PS_QUICK_ANALYSIS
        
        // Init Image Processor
        if (self.imageProcessor == nil) {
            self.imageProcessor =  kfxKENImageProcessor.instance()
            self.imageProcessor?.delegate = self;
        }
        
        // Create Quick Analysis Settings
        let qaSettings = kfxKEDQuickAnalysisSettings.init()
        
        // Blur Detection
        qaSettings.enableBlurDetection = true;
        
        // Saturation Detection
        qaSettings.enableSaturationDetection = false;
        
        // Overly Skewed Detection
        qaSettings.enableSkewDetection = false;
        
        // Low Backgound Contrast Detection
        qaSettings.enableLowContrastBackgroundDetection = false;
        
        // Missing Page Borders Detection
        qaSettings.enableMissingBordersDetection = false;
        
        // Shadow Detection
        qaSettings.enableShadowDetection = false;
        
        // Glare Detection
        qaSettings.enableGlareDetection = false;
        qaSettings.glareDetectedThreshold = 0.04;
        qaSettings.glareDetectionIntensityFraction = 0.03;
        qaSettings.glareDetectionIntensityThreshold = 230;
        qaSettings.glareDetectionMinimumGlareAreaFraction = 0.03;
        qaSettings.glareDetectionNumberOfTiles = 100;
        
        // Taregt Frame Cropping ON or OFF
        qaSettings.useTargetFrameCrop = KED_USETARGETFRAMECROP_OFF;
        
        // For Generic Documents don't use the MRZ based Passport Detection
        qaSettings.useMRZPassportDetection = KED_USEMRZDETECTION_OFF;
        
        let resp = self.imageProcessor?.doQuickAnalysis(img, andGenerateImage: true, with: qaSettings)
        
        if (resp != KMC_SUCCESS){
            self.showErrorReason(errorCode: resp ?? 0)
        }
    }
    
    // MARK: - Error Handling
    
    func showErrorReason(errorCode:Int32) {
        // Shows the corresponding KMC error message for the error code
        
        if (errorCode == KMC_SUCCESS) {
            return;
        } else {
            
            hideStatusIndicator()
            
            var errTitle = ""
            var errMessage = ""
            
            let message:String = kfxError.findErrMsg(Int32(errorCode))
            let description = kfxError.findErrDesc(Int32(errorCode))
            let split = message.components(separatedBy: ": ")
            
            if (split.count == 2) {
                errTitle = split.first ?? ""
                errMessage = String.localizedStringWithFormat("%@\n\n%@", split.first!, description!)
            } else if (split.count > 2) {
                errTitle = split.first ?? ""
                var info = "";
                
                for aSplit in split {
                    info = String.localizedStringWithFormat("%@\n\n%@", info, aSplit)
                }
                errMessage = String.localizedStringWithFormat("%@\n\n%@", info, description!)
            } else {
                errTitle = "ERROR_TITLE";
                errMessage = String.localizedStringWithFormat("%@\n\n%@", message, description!)
            }
            
            let alert = UIAlertController.init(title: errTitle, message: errMessage, preferredStyle: .alert)
            
            let positiveAlertAction = UIAlertAction.init(title: lfk.OK_TITLE.localized, style: .default) { (positiveBtn) in
                self.freeImageViewControl()
                DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                    // your function here
                    self.freeImageViewControl()
                    self.cleanObjects()
                    self.didFinishWithError()
                }
            }
            
            alert.addAction(positiveAlertAction)
            
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func didFinishWithError() {
        NSLog("[+] Error occurred");
        self.navigationController?.popToRootViewController(animated: true);
    }
    
    func cleanObjects() {
        
        // Remove all stored images and micr data
        CaptureManager.sharedInstance.clear()
    }
    
    // MARK: - kfxKIPDelegate
    
    func imageOut(_ status: Int32, withMsg errorMsg: String!, andOutputImage kfxImage: kfxKEDImage!) {
        
        if (status != KMC_SUCCESS) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.showErrorReason(errorCode:status)
            };
            return;
        }
        
        hideStatusIndicator()
        
        NSLog("[+] Finished Image Processing");
        
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            
            var micrError = ""
            var evrsMicrData = kfxImage.imageMicrData
            var micrData = evrsMicrData ?? ""
            
            if (evrsMicrData?.uppercased() == "(NULL)") {
                evrsMicrData = ""
                micrData = ""
            }
            
            print("[+] Found MIRC line: %@",evrsMicrData as Any);
            
            var micrLeft = -1;
            var micrTop = -1;
            var micrHeight = -1;
            var micrWidth = -1;
            
            if (kfxImage != nil) {
                
                // Update the MIME type of the image.
                kfxImage.imageMimeType = MIMETYPE_JPG
                
                // Check which side we are scanning and do we have teh MICR data, for Front capture MICR is required but not for Back.
                if self.currentScanSide == .FRONT {
                    if (!micrData.isEmpty){
                        // MICR Line found
                        var evrsMetaData = kfxImage.imageMetaData;
                        evrsMetaData = evrsMetaData?.components(separatedBy: "\r\n").joined(separator: " | ")
                        evrsMetaData = evrsMetaData?.components(separatedBy: "\r\n").joined(separator: " | ")
                        evrsMetaData = evrsMetaData?.components(separatedBy: "\n").joined(separator: "  ")
                        evrsMetaData = evrsMetaData?.components(separatedBy: "\t").joined(separator: "    ")
                        
                        do {
                            // make sure this JSON is in the format we expect
                            if let data = evrsMetaData?.data(using: .utf8) {
                                do {
                                    var EVRSMetaDataDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String:AnyObject]
                                    if ((EVRSMetaDataDict?.keys.contains("Front Side")) != nil) {
                                        EVRSMetaDataDict = EVRSMetaDataDict?["Front Side"] as? [String : AnyObject]
                                        
                                        if ((EVRSMetaDataDict?.keys.contains("Text Lines")) != nil) {
                                            let EVRSMICRMetaDataDict = EVRSMetaDataDict?["Text Lines"] as! [String : AnyObject]
                                            
                                            if EVRSMICRMetaDataDict.keys.contains("Lines") {
                                                let evrsMetaDataMICRArray:[AnyObject] = EVRSMICRMetaDataDict["Lines"] as! [AnyObject]
                                                
                                                for micrDict in evrsMetaDataMICRArray {
                                                    print("micrDict :: \(micrDict)")
                                                    let label = micrDict["Label"]
                                                    if (label as! String == "MICR") {
                                                        let micrValue = micrDict["OCR Data"]
                                                        if (micrValue as? String == evrsMicrData) {
                                                            
                                                            let topLeft = CGPoint.init(x: (micrDict["TLx"] as? Double ?? 0.0), y: (micrDict["TLy"] as? Double ?? 0.0))
                                                            let topRight = CGPoint.init(x: (micrDict["TRx"] as? Double ?? 0.0), y: (micrDict["TRy"] as? Double ?? 0.0))
                                                            let bottomLeft = CGPoint.init(x: (micrDict["BLx"] as? Double ?? 0.0), y: (micrDict["BLy"] as? Double ?? 0.0))
                                                            let bottomRight = CGPoint.init(x: (micrDict["BRx"] as? Double ?? 0.0), y: (micrDict["BRy"] as? Double ?? 0.0))
                                                            
                                                            //                                                            if ((topLeft.x >= 0) && (topLeft.x < kfxImage.imageWidth) && (topLeft.y > 0) && (topLeft.y < kfxImage.imageHeight) && (topRight.x > 0) && (topRight.x < kfxImage.imageWidth) && (topRight.y > 0) && (topRight.y < kfxImage.imageHeight) && (bottomLeft.x >= 0) && (bottomLeft.x <= kfxImage.imageWidth) && (bottomLeft.y >= 0) && (bottomLeft.y <= kfxImage.imageHeight) && (bottomRight.x >= 0) && (bottomRight.x <= kfxImage.imageWidth) && (bottomRight.y >= 0) && (bottomRight.y <= kfxImage.imageHeight)) {
                                                            
                                                            micrLeft = Int(topLeft.x - 1.5);
                                                            micrTop = Int(topLeft.y - 1.5) ;
                                                            micrHeight = Int(bottomLeft.y - topLeft.y + 1.5);
                                                            micrWidth = Int(bottomRight.x - topLeft.x + 1.5);
                                                            
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    EVRSMetaDataDict = nil;
                                }
                            }}catch let error as NSError {
                                print("Failed to load: \(error.localizedDescription)")
                                micrError = String.localizedStringWithFormat("Error parsing Meta Data.\n\n%s\n\n%@", #function, error as CVarArg)
                            }
                        
                        NSLog("[+] Left: %d - Top: %d - Width: %d - Height: %d",micrLeft,micrTop,micrWidth,micrHeight);
                        
                        self.micrLeft = micrLeft;
                        self.micrWidth = micrWidth;
                        self.micrHeight = micrHeight;
                        self.micrTop = micrTop;
                        self.micrLine = evrsMicrData?.replacingOccurrences(of: " ", with: "")
                        
                        // Update the MICR data
                        CaptureManager.sharedInstance.micrData = micrData
                        
                        // Add the image to the image array.
                        CaptureManager.sharedInstance.capturedImages[AppConstants.jsonParamFront] = kfxImage
                        
                        self.processStatus = .PS_IMAGE_PROCESSING_FINISHED;
                        
                        // Should the processed image be shown and waited for the User Input (Retry or Ok)?
                        if (self.shouldWaitForUserInput) {
                            self.showImage(img: kfxImage)
                            self.showOkRetryButtons(show: true)
                        }
                    }else{
                        // No MICR data available.
                        self.currentScanSide = .FRONT
                    }
                }else if self.currentScanSide == .BACK {
                    // No MICR data should be available
                    if (micrData.isEmpty) {
                        // Add the image to the image array.
                        CaptureManager.sharedInstance.capturedImages[AppConstants.jsonParamBack] = kfxImage
                        
                        self.processStatus = .PS_IMAGE_PROCESSING_FINISHED;
                        
                        // Should the processed image be shown and waited for the User Input (Retry or Ok)?
                        if (self.shouldWaitForUserInput) {
                            self.showImage(img: kfxImage)
                            self.showOkRetryButtons(show: true)
                        }
                    }else{
                        self.currentScanSide = .BACK
                        
                        let alert = UIAlertController.init(title: lfk.ERROR_TITLE.localized, message: lfk.INVALID_BACK_SCAN_ERROR.localized, preferredStyle: .alert)
                        
                        let positiveAlertAction = UIAlertAction.init(title: lfk.OK_TITLE.localized, style: .default) { (positiveBtn) in
                            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                                self.freeImageViewControl()
                                self.startCaptureProcess()
                            }
                        }
                        
                        alert.addAction(positiveAlertAction)
                        self.present(alert, animated: true, completion: nil)
                    }
                }
            }else{
                // Processed image not available
                self.freeCaptureControl()
                self.processStatus = .PS_START
                self.startCaptureProcess()
            }
        }
    }
    
    // MARK: - kfxKIPDelegate
    
    func processProgress(_ status: Int32, withMsg errorMsg: String!, imageID: String!, andProgress percent: Int32) {
        
    }
    
    func analysisComplete(_ status: Int32, withMsg errorMsg: String!, andOutputImage kfxImage: kfxKEDImage!) {
        
        if (status != KMC_SUCCESS) {
            self.showErrorReason(errorCode: status)
            return;
        }
        
        let qa:kfxKEDQuickAnalysisFeedback = kfxImage.getQuickAnalysisFeedback()
        var qualityIssues = "";
        
        if (qa.isBlurry) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_BLURRY.localized))
        }
        if (qa.isGlareDetected) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_GLARE.localized))
        }
        if (qa.isOverSaturated) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_OVERSATURATED.localized))
        }
        if (qa.isUnderSaturated) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_UNDERSATURATED.localized))
        }
        if (qa.isMissingBorders) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_MISSINGPAGEBORDERS.localized))
        }
        if (qa.isShadowed) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_SHADOW.localized))
        }
        if (qa.isOverlySkewed) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_OVERLYSKEWED.localized))
        }
        if (qa.isLowContrastBackground) {
            qualityIssues = qualityIssues.appending(String.localizedStringWithFormat("%@\n", lfk.QA_LOWBACKGROUNDCONTRAST.localized))
        }
        
        hideStatusIndicator()
        
        if (qualityIssues.count > 0) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                self.showImage(img: kfxKEDImage.init(image: qa.quickReviewUIImage))
                
                let alert = UIAlertController.init(title: lfk.QA_BAD_TITLE.localized, message: String.localizedStringWithFormat("%@\n\n%@\n\n%@", lfk.QA_BAD_TEXT1.localized,qualityIssues,lfk.QA_BAR_TEXT2.localized), preferredStyle: .alert)
                
                let positiveAlertAction = UIAlertAction.init(title: lfk.OK_TITLE.localized, style: .default) { (positiveBtn) in
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
                        // your function here
                        self.freeImageViewControl()
                        self.startCaptureProcess()
                    }
                }
                
                alert.addAction(positiveAlertAction)
                
                self.present(alert, animated: true, completion: nil)
            }
            return;
            
        } else {
            // If Quality is ok, immediately call the Image Processor?
            let immediatelyCallImageProcessoror = true
            if (immediatelyCallImageProcessoror)
            {
                self.doImageProcessing(img: self.theCurrentImage)
            }
        }
    }
    
    func analysisProgress(_ status: Int32, withMsg errorMsg: String!, imageID: String!, andProgress percent: Int32) {
        
    }
}

