//
//  CaptureManager.swift
//  Runner
//
//  Created by Vimlesh Bhatt on 11/01/2021.
//

import Foundation
import UIKit

class CaptureManager {
    
    static let sharedInstance = CaptureManager()
    
    var front = ""
    var back = ""
    var micr = ""
    
    enum Format: String {
        case png = "png"
        case jpeg = "jpeg"
    }
    
    enum SCAN_TYPE:String {
        
        case NONE = "none"
        case FRONT = "front"
        case BACK = "back"
        case BOTH = "both"
    }
    
    var capturedImages:[String:kfxKEDImage] = [:]
    var micrData = ""
    
    func clear() {
        capturedImages.removeAll()
        micr = ""
    }
    
    func imageString() -> String {
        
        var frontImageString:String = self.toBase64(image: capturedImages[AppConstants.jsonParamFront]?.getBitmap() ?? UIImage.init()) ?? ""
        var backImageString:String  = self.toBase64(image: capturedImages[AppConstants.jsonParamBack]?.getBitmap() ?? UIImage.init()) ?? ""
        var micrString = micr
        
        frontImageString = self.toBase64(image: capturedImages[AppConstants.jsonParamFront]?.getBitmap() ?? UIImage.init()) ?? ""
        backImageString  = self.toBase64(image: capturedImages[AppConstants.jsonParamBack]?.getBitmap() ?? UIImage.init()) ?? ""
        micrString = micr
        
        let messageDictionary: [String: Any] = [AppConstants.jsonParamFront:frontImageString,AppConstants.jsonParamBack:backImageString,AppConstants.jsonParamMicr: micrString]
        do {
            let jsonData = try JSONSerialization.data(withJSONObject: messageDictionary, options: [])
            let jsonString = String(data: jsonData, encoding: String.Encoding.ascii)!
            return jsonString
        } catch {
            print("Failed to get file attributes for local path with error: \(error)")
        }
        
        return ""
    }
    
    private func toBase64(image:UIImage, type: Format = .jpeg, quality: CGFloat = 1) -> String? {
        let imageData: Data?
        switch type {
        case .jpeg: imageData = jpegData(image: image, compressionQuality: quality)
        case .png:  imageData = pngData(image: image)
        }
        guard let data = imageData else { return nil }
        
        let base64 = data.base64EncodedString(options: NSData.Base64EncodingOptions(rawValue: 0))
        return base64
    }
    
    private func jpegData(image:UIImage, compressionQuality:CGFloat) -> Data? {
        guard let imageData = image.jpegData(compressionQuality: 1) else {
            return nil
        }
        return imageData;
    }
    
    private func pngData(image:UIImage) -> Data? {
        guard let imageData = image.pngData() else {
            return nil;
        }
        return imageData;
    }
}
