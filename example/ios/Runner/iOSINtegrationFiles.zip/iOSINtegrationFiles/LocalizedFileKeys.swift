//
//  LocalizedFileKeys.swift
//  Runner
//
//  Created by Vimlesh Bhatt on 29/12/2020.
//  Copyright © 2017 FAB. All rights reserved.
//


enum LocalizedFileKeys :String {
    
    case    OK_TITLE
    case    RETRY_TITLE
    case    MSG_USERINSTRUCTION_FRONT
    case    MSG_USERINSTRUCTION_BACK
    case    MSG_ZOOM_IN
    case    MSG_ZOOM_OUT
    case    MSG_CENTER
    case    MSG_CAPTUREDONE
    case    MSG_HOLDSTEADY
    case    MSG_HOLDPARALLEL
    case    MSG_ROTATE
    case    QA_BLURRY
    case    QA_OVERSATURATED
    case    QA_UNDERSATURATED
    case    QA_GLARE
    case    QA_MISSINGPAGEBORDERS
    case    QA_SHADOW
    case    QA_OVERLYSKEWED
    case    QA_LOWBACKGROUNDCONTRAST
    case    QA_BAD_TITLE
    case    QA_BAD_TEXT1
    case    QA_BAR_TEXT2
    case    ANOTHER_PAGE_TEXT
    case    ANOTHER_PAGE_BUTTON_NO
    case    ANOTHER_PAGE_BUTTON_YES
    case    STATUS_QUICK_ANALYSIS
    case    STATUS_BARCODE_EXTRACTION
    case    STATUS_IMAGE_PROCESSING
    case    STATUS_DATA_EXTRACTION
    case    STATUS_PROCESSING_DOCUMENT
    case    ERROR_TITLE
    case    ERROR_NO_BARCODE_FOUND
    case    ERROR_CALLING_EXTRACTION
    case    ERROR_NO_EXTRACTION_RESULT
    case    ERROR_CODE
    case    CAMERA_VIEW_FRONT_HINT_TEXT
    case    CAMERA_VIEW_BACK_HINT_TEXT
    case    REVIEW_ERROR
    case    PROCESS_ERROR
    case    CANCELLED_ERROR
    case    INVALID_BACK_SCAN_ERROR
    
    var localized : String {
        return self.rawValue.localized
    }
}
