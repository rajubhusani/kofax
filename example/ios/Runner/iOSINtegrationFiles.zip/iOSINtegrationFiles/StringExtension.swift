//
//  StringExtension.swift
//  Runner
//
//  Created by Vimlesh Bhatt on 29/12/2020.
//  Copyright © 2017 FAB. All rights reserved.
//

import Foundation
import UIKit

extension String {
    
    var localized: String {
        let localizedString = NSLocalizedString(self, tableName: nil, bundle: Bundle.main, value: "", comment: "")
        return localizedString
    }
}
